import 'package:flutter/material.dart';

class LupaPasswordPage extends StatefulWidget {
  @override
  _LupaPasswordPageState createState() => _LupaPasswordPageState();
}

class _LupaPasswordPageState extends State<LupaPasswordPage> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
