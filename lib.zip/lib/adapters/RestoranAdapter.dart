import 'package:flutter/material.dart';
import 'package:kuliner_majalengka_training/models/Restoran.dart';

class RestoranAdapter extends StatelessWidget {
  final Restoran restoran;

  RestoranAdapter(this.restoran);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: 8),
      child: Card(
        color: Colors.white,
        //merubah derajat sudut
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        child: Column(
          children: <Widget>[
            Image.network(restoran.image, width: double.infinity, height: 180, fit: BoxFit.cover,)
          ],
        ),
      ),
    );
  }
}
