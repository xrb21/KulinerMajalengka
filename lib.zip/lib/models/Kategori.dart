class Kategori {
  final int id;
  final String nama;
  final String image;
  final int jumlah;

  Kategori({this.id, this.nama, this.image, this.jumlah});
}